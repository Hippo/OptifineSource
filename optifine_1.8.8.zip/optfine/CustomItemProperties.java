package optfine;

public class CustomItemProperties
{
}
