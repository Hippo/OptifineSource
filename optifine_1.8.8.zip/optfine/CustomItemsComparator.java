package optfine;

import java.util.Comparator;

public class CustomItemsComparator implements Comparator
{
    public int compare(Object p_compare_1_, Object p_compare_2_)
    {
        return 0;
    }
}
