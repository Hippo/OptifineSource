package optfine;

public class CustomAnimationFrame
{
    public int index = 0;
    public int duration = 0;
    public int counter = 0;

    public CustomAnimationFrame(int p_i30_1_, int p_i30_2_)
    {
        this.index = p_i30_1_;
        this.duration = p_i30_2_;
    }
}
